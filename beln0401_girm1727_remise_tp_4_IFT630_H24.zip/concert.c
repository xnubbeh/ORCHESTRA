#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h> // Pour les constantes O_CREAT et O_EXCL, pour les soucis de compatibilités
#include <unistd.h>

#define NB_MUSICIENS 10

sem_t *signal_du_chef;
sem_t *mutex;
int nb_musiciens_prets = 0;
char *instruments[10] = {
        "Piano",
        "Violon",
        "Guitare",
        "Flûte",
        "Trompette",
        "Saxophone",
        "Batterie",
        "Harpe",
        "Tambourin",
        "Violoncelle"
    };

void jouer_et_choisir_instrument(int musicien_id) {
    printf("Je suis le musicien N° %d qui joue son instrument de type %s.\n", musicien_id, instruments[musicien_id - 1]);
    usleep(rand() % 1000000);
}

void *musicien(void *id) {
    int musicien_id = *((int *)id);

    // Attendre que tous les musiciens soient prêts
    // TODO
    sem_wait(mutex);
    
    
    // Jouer son instrument
    jouer_et_choisir_instrument(musicien_id);
    nb_musiciens_prets++;

    // Signaler au chef_orchestre_musicien d'orchestre qu'il a joué
    // TODO
    sem_post(mutex);
    //nb_musiciens_prets--;
    
    // Si tous les musiciens ont joué, signaler au chef_orchestre_musicien d'orchestre
    // TODO
    if(nb_musiciens_prets == NB_MUSICIENS){
        sem_post(signal_du_chef);
    }
    sem_post(mutex);
    //pthread_exit(NULL);
}

void *chef_orchestre(void *arg) {
    // Attendre que tous les musiciens soient prêts
    for (int i = 0; i < NB_MUSICIENS; i++) {
        sem_post(signal_du_chef);
    }

    // Attendre que tous les musiciens aient joué
    // TODO
    //sem_wait(signal_du_chef);
    sem_wait(mutex);
    if(nb_musiciens_prets == 0){
        sem_post(mutex);
    }
    // Donner le signal pour jouer tous ensemble
    printf("Chef d'orchestre donne le signal pour jouer tous ensemble !\n");

    pthread_exit(NULL);
}

int main() {
    pthread_t musiciens[NB_MUSICIENS], chef_orchestre_musicien;
    int id_musicien[NB_MUSICIENS];

    // Création des sémaphores
    signal_du_chef = sem_open("/signal_du_chef", O_CREAT | O_EXCL, 0644, 0);
    mutex = sem_open("/mutex", O_CREAT | O_EXCL, 0644, 1);

    // Création des threads musiciens
    // TODO
    for(int i=0;i<NB_MUSICIENS;i++){
        id_musicien[i] = i+1;
        pthread_create((&musiciens[i]),NULL,musicien,(void *)&id_musicien[i]);
    }
    // Création du thread chef_orchestre_musicien d'orchestre
    pthread_create(&chef_orchestre_musicien, NULL, chef_orchestre, NULL);

    // Attente des threads
    // TODO
    for(int i=0;i<NB_MUSICIENS;i++){
        pthread_join(musiciens[i],NULL);
    }

    pthread_join(chef_orchestre_musicien, NULL);

    // Fermeture et suppression des sémaphores
    sem_close(signal_du_chef);
    sem_close(mutex);
    sem_unlink("/signal_du_chef");
    sem_unlink("/mutex");

    return 0;
}